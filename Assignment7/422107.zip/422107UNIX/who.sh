#!/bin/bash

# Print information about currently logged in users
who

