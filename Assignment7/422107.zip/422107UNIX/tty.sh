#!/bin/bash

# Print the file name of the terminal connected to standard input
tty

